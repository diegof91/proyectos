﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dominio
{
    public class Factura : IComparable<Factura>
    {
        #region Atributos
        private List<Linea> lineas = new List<Linea>();
        private string formaDePago;
        private string formaDeEntrega;
        private DateTime fechaCompra;
        private Cliente cliente;
        private decimal totalCompra;
        private int articulos;

        #endregion
        #region Propiedades GET/SET
        public List<Linea> Lineas
        {
            get { return lineas; }
        }
        public string FormaDePago
        {
            get { return formaDePago; }
            set { formaDePago = value; }
        }
        public string FormaDeEntrega
        {
            get { return formaDeEntrega; }
            set { formaDeEntrega = value; }
        }
        public DateTime FechaCompra
        {
            get { return fechaCompra; }
            set { fechaCompra = value; }
        }
        public Cliente Cliente
        {
            get { return cliente; }
            set { cliente = value; }

        }
        public int Articulos
        {
            get { return articulos; }
            set { articulos = value; }

        }

        public decimal TotalCompra
        {
            get { return totalCompra; }
            set { totalCompra = value; }
        }
        #endregion
        #region Constructor
        public Factura()
        {
            
        }
        public Factura(string formaDePago, string formaDeEntrega, DateTime fechaCompra, List<Linea> lineas, Cliente cliente)
        {
            this.formaDePago = formaDePago;
            this.formaDeEntrega = formaDeEntrega;
            this.fechaCompra = fechaCompra;
            this.cliente = cliente;
            this.lineas = lineas;
            this.totalCompra = CalcularTotalCompra();
            this.articulos = SumaCantidadArticulos();
            //this.totalCompra = Sistema.Compra();
        }
        #endregion
        #region Override ToString
        public override string ToString()
        {
            string aux = ""; // el tostring fue modificado para mostrar lo que pide la letra.

            if (lineas != null)

                foreach (Linea l in lineas)
                {
                    aux += "\n" + l;
                    

                }

            aux += "\nForma de pago: " + formaDePago;
            aux += "\nForma de entrega: " + formaDeEntrega;
            aux += "\nFecha de compra: " + fechaCompra;
            



            return aux;
        }
        #endregion
        #region Metodos
        ////////////////////////////Metodo comentado. Se usaba para agregar lineas en una version anterior////////////////////////////


        public decimal CalcularTotalCompra()
        {
            decimal precioTotal = 0;
          

            foreach(Linea unaL in lineas)
            {
               if (unaL.Producto.Exclusividad == "si") {
                    precioTotal += ((unaL.Cantidad / 2) + (unaL.Cantidad % 2)) * unaL.Producto.PrecioUnit;
                }
                
               else if(unaL.Producto.Exclusividad == "no")
                    precioTotal += unaL.Producto.PrecioUnit *  unaL.Cantidad;
            }

            return precioTotal;
        }

        public int CompareTo(Factura other)
        {
            return fechaCompra.CompareTo(other.fechaCompra) * -1;
        }

        public int SumaCantidadArticulos()
        {
            int articulos = 0;
            foreach(Linea l in lineas)
            {
                articulos += l.Cantidad;
            }
            return articulos;
        }
        #endregion
    }
}
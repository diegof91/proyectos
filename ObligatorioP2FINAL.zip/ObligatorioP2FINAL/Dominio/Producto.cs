﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dominio
{
    public class Producto
    {
        #region Atributos
        public int id;
        private static int idproducto = 0;
        private string nombre;
        private string descripcion;
        private string exclusividad;
        private string categoria;
        private decimal precioUnit;
        #endregion
        #region Propiedades GET/SET
        public int Id
        {
            get { return id; }
            set { id = value; }
        }
        public string Nombre
        {
            get { return nombre; }
            set { nombre = value; }
        }
        public string Descripcion
        {
            get { return descripcion; }
            set { descripcion = value; }
        }
        public string Exclusividad
        {
            get { return exclusividad; }
            set { exclusividad = value; }
        }
        public string Categoria
        {
            get { return categoria; }
            set { categoria = value; }
        }
        public decimal PrecioUnit
        {
            get { return precioUnit; }
            set { precioUnit = value; }
        }
        #endregion
        #region Constructor
        public Producto()
        {
            this.id = idproducto++;
        }
        public Producto(string nombre, string descripcion, string exclusividad, string categoria, decimal precioUnit)
        {
            idproducto += 1;
            this.id = idproducto;
            this.nombre = nombre;
            this.descripcion = descripcion;
            this.exclusividad = exclusividad;
            this.categoria = categoria;
            this.precioUnit = precioUnit;
        }
        #endregion
        #region Override ToString
        public override string ToString()
        {
            string aux = "";
            aux += "\nId: " + id;
            aux += "\nNombre: " + nombre;
            aux += "\nDescripcion: " + descripcion;
            aux += "\nExclusividad: " + exclusividad;
            aux += "\nCategoria: " + categoria;
            aux += "\nPrecio Unitario: " + precioUnit;
            return aux;

        }
        #endregion
        #region Metodos
        ////////////////////////////Metodos para Validar datos////////////////////////////
        public static bool ValidarExclusividad(string exclusividad)
        {
            bool exito = false;
            string aux = exclusividad.ToLower();
            if (aux == "si" || aux == "no")
                exito = true;
            else
                exito = false;
            return exito;
        }
        public static bool ValidarCategoria(string categoria)
        {
            bool exito = false;
                string aux = categoria.ToLower();
                if (aux == "frescos" || aux == "congelados" || aux == "hogar" || aux == "textiles" || aux == "tecnologia")
                exito = true;
            return exito;
        }
        public static bool ValidarEntradaDatos(string nombre, string descripcion, string exclusividad, string categoria, decimal precioUnit)
        {
            bool exito = false;
                if (nombre.Length > 0 && descripcion.Length > 0 && exclusividad.Length > 0 && categoria.Length > 0 && precioUnit > 0)
                exito = true;
            return exito;
        }
        #endregion
    }
}

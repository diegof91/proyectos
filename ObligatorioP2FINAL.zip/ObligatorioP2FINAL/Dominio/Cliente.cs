﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dominio
{
    public  abstract class Cliente
    {
        ////////////////////////////El Atributo estatico descuento fue incluido ya que esta en la letra pero no es utilizado////////////////////////////
        #region Atributos
        private string nombre;
        private string mailUnico;
        private string direccion;
        private string mvd;
        private DateTime fechaIngreso;
        private Usuario usuario; // ASIGNE OBJETO USUARIO COMO ATRIBUTO

        /*private static double descuento;*/
        #endregion
        #region Propiedades GET/SET
        public string Nombre
        {
            get { return nombre; }
            set { nombre = value; }
        }
        public string MailUnico
        {
            get { return mailUnico; }
            set { mailUnico = value; }
        }
        public string Direccion
        {
            get { return direccion; }
            set { direccion = value; }
        }
        public string Mvd
        {
            get { return mvd; }
            set { mvd = value; }
        }
        public DateTime FechaIngreso
        {
            get { return fechaIngreso; }
            set { fechaIngreso = value; }
        }
       
        
        //public static double Descuento
        //{
        //    get { return descuento; }
        //    set { descuento = value; }
        //}

        public  Usuario Usuario // AGREGUE PROPERTY USUARIO
        {
            get { return usuario; }
            set { usuario = value; }
        }
        #endregion
        #region Constructor 
        // AGREGUE USUARIO A CONSTRUCTOR

            public Cliente()
        {

        }
        public Cliente(string nombre, string mailUnico, string direccion, string mvd, DateTime fechaIngreso,Usuario usuario)
        {
            this.nombre = nombre;
            this.mailUnico = mailUnico;
            this.direccion = direccion;
            this.mvd = mvd;
            this.fechaIngreso = fechaIngreso;
            this.usuario = usuario;
            
            
        }
        #endregion
        #region Override ToString
        public override string ToString()
        {
            string aux = "";
            aux += "\nNombre: " + nombre;
            aux += "\nEmail: " + mailUnico;
            aux += "\nDireccion: " + direccion;
            aux += "\nLocalidad: " + mvd;
            aux += "\nFechaIngreso: " + fechaIngreso.ToShortDateString();
            /*aux += "\nUsuario: " + usuarioUnico;*/
            
            return aux;
        }
        #endregion
        #region Metodos
        ////////////////////////////Metodos para Validar datos////////////////////////////
        public static bool ValidarMVD(string mvd)
        {
            bool exito = false;
            string aux = mvd.ToLower();
            if (aux == "montevideo" || aux == "interior")
                exito = true;
            return exito;
        }

        public abstract decimal CalcularDescuento();
        
        #endregion
    }
}


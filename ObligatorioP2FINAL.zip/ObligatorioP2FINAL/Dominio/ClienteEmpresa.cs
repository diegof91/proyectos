﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dominio
{
    public class ClienteEmpresa : Cliente
    {
        #region Atributos
        private string rut;
        private string razonSocial;
        #endregion
        #region Propiedades GET/SET
        public string Rut
        {
            get { return rut; }
            set { rut = value; }
        }
        public string RazonSocial
        {
            get { return razonSocial; }
            set { razonSocial = value; }
        }
        #endregion
        #region Constructor
        // AGREGUE USUARIO, SAQUE STRING USUARIO UNICO
        public ClienteEmpresa(string nombre, string mailUnico, string direccion, string mvd, DateTime fechaIngreso, Usuario usuario,  string rut, string razonSocial) : base(nombre, mailUnico, direccion, mvd, fechaIngreso, usuario)
        {
            this.rut = rut;
            this.razonSocial = razonSocial;
        }
        #endregion
        #region Override ToString
        public override string ToString()
        {
            string aux = "CLIENTE EMPRESA";
            aux += base.ToString();
            aux += "\nRUT: " + rut;
            aux += "\nRazon Social: " + razonSocial;
            return aux;
        }
        #endregion
        #region Metodos
        ////////////////////////////Metodos para Validar datos////////////////////////////
        public static bool ValidarRut(string rut)
        {
            return rut.Length == 12;
        }

        public override decimal CalcularDescuento()
        {
            decimal descuentoGeneral = 1;
            double antiguedad = (DateTime.Now - FechaIngreso).TotalDays;
            if (antiguedad > 730 && antiguedad <= 1825)
            {
                descuentoGeneral = descuentoGeneral - (descuentoGeneral*5/100);
            }


            else if (antiguedad > 1825)
                descuentoGeneral = descuentoGeneral - (descuentoGeneral*10/100);

            return descuentoGeneral;
        }
        #endregion
    }
}
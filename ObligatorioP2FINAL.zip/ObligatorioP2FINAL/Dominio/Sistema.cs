﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dominio
{
    public class Sistema
    {
        #region Atributos
        private List<Cliente> clientes = new List<Cliente>();
        private List<Producto> productos = new List<Producto>();
        private List<Factura> facturas = new List<Factura>();
        private List<Usuario> usuarios = new List<Usuario>(); // AGREGUE LISTA USUARIOS
        public List<Linea> aux = new List<Linea>();
        private static Sistema instancia;
        #endregion
        #region Propiedades
        public List<Linea> Aux {
            get { return aux; }
        }
        public List<Cliente> Clientes
        {
            get { return clientes; }
        }
        public List<Producto> Productos
        {
            get { return productos; }
        }
        public List<Factura> Facturas
        {
            get { return facturas; }
        }

        public List<Usuario> Usuarios // AGREGUE PROPERTY USUARIO
        {
            get { return usuarios; }
        }
        #endregion
        #region Metodo Sistema, Precargas y Agregar
        ////////////////////////////En esta seccion se encuentra la precarga de datos y los metodos relacionados a agregar items (Clientes, Productos, Facturas)////////////////////////////
        public static Sistema Instancia
        {
            get
            {
                if (instancia == null)
                    instancia = new Sistema();
                return instancia;
            }
        }

        private Sistema()
        {
            PrecargaAdmin();
            PrecargaProductos();
            PrecargaClienteComun();
            PrecargaClienteEmpresa();
            PrecargaVentas();
        }

        public void PrecargaAdmin()
        {
            //PRECARGA USUARIOS ADMIN ( LA PRECARGA DE USUARIOS CLIENTE LA HICE JUNTO A PRECARGAR CLIENTE)
            usuarios.Add(new Usuario("admin1", "admin123", "admin"));
            usuarios.Add(new Usuario("admin2", "admin123", "admin"));
        }
        public void PrecargaProductos()
        {
            AgregarProducto("Jane", "hipoclorito de sodio", "no", "hogar", 48);
            AgregarProducto("papa blanca", "papas", "no", "frescos", 32);
            AgregarProducto("jamon cocido Centenario", "jamon cocido", "no", "frescos", 40);
            AgregarProducto("fideos HUV", "fideos Habia una Vez", "si", "frescos", 48);
            AgregarProducto("licuadora Moulinex", "licuadora", "no", "hogar", 890);
            AgregarProducto("teclado inhalambrico Logitech", "teclado", "no", "tecnologia", 399);
            AgregarProducto("papas fritas McCain", "papas fritas", "no", "congelados", 150);

            //CARGAS ERRONEAS
            AgregarProducto("Jane", "hipoclorito", "no", "hogar", 48);
            AgregarProducto("ruleta", "Rusa", "niidea", "tecnologia", 150000);
            AgregarProducto("panchos", "Schneck", "no", "panchipancho", 129);
            AgregarProducto("hamburguesas", "", "no", "congelados", 165);
        }
        public void PrecargaClienteComun()
        {
            Usuario usuario1 = new Usuario("Plablitox227", "pablito123", "cliente"); // CREE OBJETOS USUARIO
            Usuario usuario2 = new Usuario("RomanC123", "roman123", "cliente");
            Usuario usuario3 = new Usuario("LaufainDVir", "laufain123", "cliente");
            Usuario usuario4 = new Usuario("CarmeCarme88", "carme123", "cliente");

            DateTime fechaIngreso1 = new DateTime(2019, 10, 01);
            DateTime fechaIngreso2 = new DateTime(2019, 09, 30);
            DateTime fechaIngreso3 = new DateTime(2013, 09, 27);
            AgregarClienteComun("Pablo Garcia", "pablo.garcia@gmail.com", "MarCantabrico MB11", "Interior", fechaIngreso1, usuario1, "30401825", "099582667");
            AgregarClienteComun("Roman Correa", "romancorrea@gmail.com", "MarCantabrico MB11 S26", "interior", fechaIngreso3, usuario2, "30401824", "098460866");
            AgregarClienteComun("Laufain", "laufainthedarkelf@d&d.com", "MarCantabrico MB11 S26", "interior", fechaIngreso2, usuario3, "11111111", "111111111");
            AgregarClienteComun("Carmela Rodriguez", "carmelitaroro@hotmail.com", "Solano Antuña", "Montevideo", fechaIngreso2, usuario4, "30401826", "098466889");

            //CARGAS ERRONEAS
            AgregarClienteComun("Juan Gutierrez", "gutiegutie@hotmail.com", "21 Setiembre", "Montevideo", fechaIngreso3, usuario1, "2482345", "095866966");
            AgregarClienteComun("James Jameson", "jjjjjjjjjjj@gmail.com", "nowhere", "Montevideo", fechaIngreso3, usuario2, "10101010", "10101010");
            AgregarClienteComun("Carmela Rodriguez2", "carmelitaroro2@hotmail.com", "MurderAlley", "GothamCity", fechaIngreso2, usuario3, "89695551", "098466889");
            AgregarClienteComun("Carmela Rodriguez2", "carmelitaroro2@hotmail.com", "Solano Antuña2", "montevideo", fechaIngreso3, usuario4, "30401828", "098466889");
        }
        public void PrecargaClienteEmpresa()
        {
            Usuario usuario5 = new Usuario("bani", "bani123", "cliente"); //IDEM ANTERIOR
            Usuario usuario6 = new Usuario("queri", "queri123", "cliente");
            Usuario usuario7 = new Usuario("peti", "peti123", "cliente");

            DateTime fecha = new DateTime(2019, 07, 05);
            /*fecha = new DateTime(2019, 6, 6);*/
            AgregarClienteEmpresa("banilur", "banilur@gmail.com", "aca", "interior", fecha, usuario5, "123456789111", "SA");
            AgregarClienteEmpresa("querinur", "querinur@gmail.com", "aca", "montevideo", fecha, usuario6, "123456789112", "SA");
            AgregarClienteEmpresa("petilur", "petilur@gmail.com", "aca", "interior", fecha, usuario7, "123456789113", "SRL");
            AgregarClienteEmpresa("banilur", "banilurr@gmail.com", "aca", "montevideo", fecha, usuario7, "123456789111", "SA");
        }
        public void PrecargaVentas()
        {
            //////////VENTA 1/////////
            DateTime fechaCompra1 = new DateTime(2019, 10, 12);
            Cliente C1 = BuscarCliente("romancorrea@gmail.com");
            Producto P1 = BuscarProducto(1);
            Producto P2 = BuscarProducto(2);
            Linea L1 = new Linea(P1, 2, 96);
            Linea L2 = new Linea(P2, 7, 224);
            List<Linea> lineas = new List<Linea>();
            lineas.Add(L1);
            lineas.Add(L2);    // CAMBIE EL PARAMETRO DE AGREGAR FACTURA, ANTES POR USUARIOUNICO, AHORA POR EMAIL.
            AgregarFacturaPre("efectivo", "domicilio", fechaCompra1, lineas ,C1);

            //////////VENTA 2/////////
            DateTime fechaCompra2 = new DateTime(2018, 02, 10);
            Cliente C2 = BuscarCliente("laufainthedarkelf@d&d.com");
            Producto P3 = BuscarProducto(3);
            Producto P4a = BuscarProducto(4);
            Linea L3 = new Linea(P3, 1, 40);
            Linea L4a = new Linea(P4a, 2, 96);
            List<Linea> lineas2 = new List<Linea>();
            List<Linea> aux2 = new List<Linea>();
            lineas2.Add(L3);
            lineas2.Add(L4a);
            AgregarFacturaPre("credito", "domicilio", fechaCompra2, lineas2, C2);

            //////////VENTA 3/////////
            DateTime fechaCompra3 = new DateTime(2019, 10, 08);
            Cliente C3 = BuscarCliente("carmelitaroro@hotmail.com");
            Producto P4b = BuscarProducto(4);
            Producto P5 = BuscarProducto(5);
            Linea L4b = new Linea(P4b, 2, 96);
            Linea L5 = new Linea(P5, 1, 890);
            List<Linea> lineas3 = new List<Linea>();
            List<Linea> aux3 = new List<Linea>();
            lineas3.Add(L4b);
            lineas3.Add(L5);
            AgregarFacturaPre("credito", "domicilio", fechaCompra3, lineas3, C3);

            //////////VENTA 4/////////
            DateTime fechaCompra4 = new DateTime(2018, 04, 08);
            Cliente C4 = BuscarCliente("carmelitaroro@hotmail.com");
            Producto P6 = BuscarProducto(6);
            Producto P7 = BuscarProducto(7);
            Linea L6 = new Linea(P6, 3, 1197);
            Linea L7 = new Linea(P7, 8, 1200);
            List<Linea> lineas4 = new List<Linea>();
            List<Linea> aux4 = new List<Linea>();
            lineas4.Add(L6);
            lineas4.Add(L7);
            AgregarFacturaPre("credito", "domicilio", fechaCompra4, lineas4, C4);

            //////////VENTA 5/////////
            DateTime fechaCompra5 = new DateTime(2019, 03, 15);
            Cliente C5 = BuscarCliente("pablo.garcia@gmail.com");
            Producto P5b = BuscarProducto(5);
            Producto P1b = BuscarProducto(1);
            Linea L5b = new Linea(P5b, 6, 4450);
            Linea L1b = new Linea(P1b, 8, 384);
            List<Linea> lineas5 = new List<Linea>();
            List<Linea> aux5 = new List<Linea>();
            lineas5.Add(L5b);
            lineas5.Add(L1b);
            AgregarFacturaPre("credito", "domicilio", fechaCompra5, lineas5, C5);

            //////////VENTA 6/////////
            DateTime fechaCompra6 = new DateTime(2018, 01, 15);
            Cliente C6 = BuscarCliente("pablo.garcia@gmail.com");
            Producto P3b = BuscarProducto(1);
            Producto P2b = BuscarProducto(2);
            Linea L3b = new Linea(P3b, 1, 40);
            Linea L2b = new Linea(P2b, 10, 320);
            List<Linea> lineas6 = new List<Linea>();
            List<Linea> aux6 = new List<Linea>();
            lineas6.Add(L3b);
            lineas6.Add(L2b);
            AgregarFacturaPre("credito", "domicilio", fechaCompra5, lineas6, C6);
        }
        public bool AgregarProducto(string nombre, string descripcion, string exclusividad, string categoria, decimal precioUnit)
        {
            bool exito = false;
            if (Producto.ValidarExclusividad(exclusividad) && Producto.ValidarCategoria(categoria) && Producto.ValidarEntradaDatos(nombre, descripcion, exclusividad, categoria, precioUnit) && !BuscarProductoPorNombre(nombre))
            {
                Producto unProducto = new Producto(nombre, descripcion, exclusividad, categoria, precioUnit);
                productos.Add(unProducto);
                exito = true;
            }
            return exito;
        }

        //public Usuario agregarUsuario(string nombreusuario,string password,string rol)
        //{
        //    Usuario u = new Usuario(nombreusuario, password, rol);
        //    usuarios.Add(u);

        //}

        public bool AgregarClienteComun(string nombre, string mailUnico, string direccion, string mvd, DateTime fechaIngreso, Usuario usuario, string ci, string celular)
        {                                                                                    //CAMBIE STRING USUARIOUNICO POR Usuario Usuario
            bool exito = false;

            // CAMBIE METODO DE BUSCARCLIENTE POR BUSCARUSUARIO, ME DEVUELVE OBJETO USUARIO. SI ES NULL, SE AGREGA. SINO NO, YA QUE SE REPETIRIA EL USUARIO
            if (!BuscarCedula(ci) && !BuscarEmail(mailUnico) && ClienteComun.ValidarCedula(ci) && ClienteComun.ValidarCelular(celular) && Cliente.ValidarMVD(mvd) && BuscarUsuario(usuario.NombreUsuario, usuario.Password) == null)
            {
                Usuario unU = new Usuario(usuario.NombreUsuario, usuario.Password, usuario.Rol);
                ClienteComun unCliente = new ClienteComun(nombre, mailUnico, direccion, mvd, fechaIngreso, usuario, ci, celular);
                unCliente.Usuario.Rol = "cliente"; // UNA VEZ QUE EL CLIENTE SE CREA, SE LE ASIGNA AUTOMATICAMENTE EL ATRIBUTO ROL="CLIENTE"
                clientes.Add(unCliente);
                usuarios.Add(unU); // NOSE SI ESTA BIEN. UNA VEZ QUE EL CLIENTE SE CREA, SE AGREGA A LA LISTA DE USUARIOS EL OBJETO USUARIO DEL CLIENTE CREADO.

                exito = true;
            }
            return exito;
        }
        public bool AgregarClienteEmpresa(string nombre, string mailUnico, string direccion, string mvd, DateTime fechaIngreso, Usuario usuario, string rut, string razonSocial)
        {
            bool exito = false; // IDEM ANTERIOR
            if (ClienteEmpresa.ValidarRut(rut) && !BuscarEmail(mailUnico) && Cliente.ValidarMVD(mvd) && !BuscarRut(rut) && BuscarUsuario(usuario.NombreUsuario, usuario.Password) == null)
            {
                Usuario unU = new Usuario(usuario.NombreUsuario, usuario.Password, usuario.Rol);
                ClienteEmpresa unEmpresa = new ClienteEmpresa(nombre, mailUnico, direccion, mvd, fechaIngreso, usuario, rut, razonSocial);
                unEmpresa.Usuario.Rol = "cliente";
                clientes.Add(unEmpresa);
                usuarios.Add(unU);

                exito = true;
            }
            return exito;
        }
        //public bool AgregarFactura(string email, int id, int cantidad, string formaDePago, string formaDeEntrega, DateTime fechaCompra, List<Linea> lineas)
        //{
        //    bool exito = false;
        //    Cliente unCliente = BuscarCliente(email); // METODO BUSCAR CLIENTE BUSCA POR EMAIL, EN VEZ DE POR USUARIOUNICO.
        //    Producto unProducto = BuscarProducto(id);

        //    if (unCliente != null && unProducto != null)
        //    {
        //        Factura F = new Factura(formaDePago, formaDeEntrega, fechaCompra, lineas, unCliente);
        //        decimal total = unProducto.PrecioUnit * cantidad;
        //        Linea unaLinea = new Linea(unProducto, cantidad, total);
        //        F.Lineas.Add(unaLinea);
        //        facturas.Add(F);
        //        exito = true;
        //    }
        //    return exito;
        //}

        public Factura AgregarFacturaPre(string formaDePago, string formaDeEntrega, DateTime fechaCompra, List<Linea> lineas, Cliente unCliente)
        {
            Factura unF = null;        
            if (unCliente != null )
            {
                Factura F = new Factura(formaDePago, formaDeEntrega, fechaCompra, lineas, unCliente);
                //unF = F;
                //decimal total = unProducto.PrecioUnit * cantidad;
                //Linea unaLinea = new Linea(unProducto, cantidad, total);
                //F.Lineas.Add(unaLinea);
                F.TotalCompra = DescuentoFormaDePagoYDpto(F);
                facturas.Add(F);
                //Sistema.Instancia.aux.Clear();
            }
            return unF;
        }

        public Factura AgregarFactura(string formaDePago, string formaDeEntrega, DateTime fechaCompra, List<Linea> aux, Cliente unCliente)
        {
            Factura unF = null;
            if (unCliente != null)
            {
                Factura F = new Factura(formaDePago, formaDeEntrega, fechaCompra, aux, unCliente);
                unF = F;
                //decimal total = unProducto.PrecioUnit * cantidad;
                //Linea unaLinea = new Linea(unProducto, cantidad, total);
                //F.Lineas.Add(unaLinea);
                F.TotalCompra = DescuentoFormaDePagoYDpto(F);
                facturas.Add(F);
            }
            return unF;
        }

        //public Factura AgregarFacturaPre(string formaDePago, string formaDeEntrega, DateTime fechaCompra, List<Linea> lineas, Cliente unCliente)
        //{
        //    Factura unF = null;
        //    if (unCliente != null)
        //    {
        //        Factura F = new Factura(formaDePago, formaDeEntrega, fechaCompra, lineas, unCliente);
        //        unF = F;

        //        facturas.Add(F);

        //    }
        //    return unF;
        //}

        public Linea AgregarProductoALinea(int id, int cantidad)
        {
            Producto producto = BuscarProducto(id);
            decimal total = producto.PrecioUnit * cantidad;
            Linea unLinea = new Linea(producto, cantidad, total);
            aux.Add(unLinea);
            return unLinea;
        }
        #endregion
        #region Otros Metodos
        ////////////////////////////En esta seccion se encuentran los metodos para Listar y Buscar items////////////////////////////


        ////////////////////////////Metodos para Listar items////////////////////////////
        public List<Producto> ListarProductos()
        {
            List<Producto> aux = new List<Producto>();
            foreach (Producto unProducto in productos)
            {
                aux.Add(unProducto);
            }
            /*if (aux == null)
                Console.WriteLine("No se han encontrado productos bajo esta Categoria.");*/
            return aux;
        }
        public List<Producto> ListarProductosCategoria(string categoria)
        {
            List<Producto> aux = new List<Producto>();
            foreach (Producto unProducto in productos)
            {
                if (unProducto.Categoria == categoria)
                    aux.Add(unProducto);
            }
            /*if (aux == null)
                Console.WriteLine("No se han encontrado productos bajo esta Categoria.");*/
            return aux;
        }
        public string ListarClienteComun()
        {
            string aux = "";

            if (clientes.Count == 0)
                aux = "Aun no hay clientes";
            else
            {
                foreach (Cliente unCliente in clientes)
                {
                    aux += unCliente + "\n\n";
                }
            }
            return aux;
        }
        public List<Cliente> ListarClientesPorFecha(DateTime fecha)
        {
            List<Cliente> aux = new List<Cliente>();
            foreach (Cliente unCliente in clientes)
            {
                if (unCliente.FechaIngreso <= fecha)
                    aux.Add(unCliente);
            }
            return aux;
        }
        public List<Factura> ListarFactura()
        {
            List<Factura> aux = new List<Factura>();
            foreach (Factura unFactura in facturas)
            {
                aux.Add(unFactura);
            }
            return aux;
        }
        public List<Factura> ListarComprasPorFecha(DateTime fecha1, DateTime fecha2)
        {
            List<Factura> aux = new List<Factura>();

            foreach (Factura unF in facturas)
            {
                if (unF.FechaCompra >= fecha1 && unF.FechaCompra <= fecha2)
                    aux.Add(unF);
            }
            return aux;

        }

        ////////////////////////////Metodos para Buscar items////////////////////////////
        public Producto BuscarProducto(int id)
        {
            int i = 0;
            Producto productoEncontrado = null;
            while (productoEncontrado == null && i < productos.Count)
            {
                if (productos[i].Id == id)
                    productoEncontrado = productos[i];
                else
                    i++;
            }
            return productoEncontrado;
        }

        public bool modificarPrecioProducto(int id, decimal precioUnit)
        {
            bool exito = false;
            Producto p = BuscarProducto(id);
            if (p != null)
            {
                p.PrecioUnit = precioUnit;
                exito = true;
            }

            return exito;
        }

        public bool BuscarProductoPorNombre(string nombre)
        {
            bool exito = false;
            int i = 0;
            while (!exito && i < productos.Count)
            {
                if (productos[i].Nombre == nombre)
                    exito = true;
                else
                    i++;
            }
            return exito;
        }
        public Usuario BuscarUsuario(string nombre, string password) // METODO CREADO DEVUELVE USUARIO ENCONTRADO O NO
        {
            int i = 0;
            Usuario usuarioEncontrado = null;
            while (usuarioEncontrado == null && i < usuarios.Count)
            {
                if (usuarios[i].NombreUsuario == nombre && usuarios[i].Password == password)
                    usuarioEncontrado = usuarios[i];
                else
                    i++;
            }
            return usuarioEncontrado;
        }

        public Cliente BuscarCliente(string email) // METODO CREADO DEVUELVE CLIENTE ENCONTRADO O NO
        {
            int i = 0;
            Cliente clienteEncontrado = null;
            while (clienteEncontrado == null && i < clientes.Count)
            {
                if (clientes[i].MailUnico == email)
                    clienteEncontrado = clientes[i];
                else
                    i++;
            }
            return clienteEncontrado;
        }

        public Cliente BuscarClientePorNombre(string nombreUsuario) // METODO CREADO DEVUELVE CLIENTE ENCONTRADO O NO
        {
            int i = 0;
            Cliente clienteEncontrado = null;
            while (clienteEncontrado == null && i < clientes.Count)
            {
                if (clientes[i].Usuario.NombreUsuario == nombreUsuario)
                    clienteEncontrado = clientes[i];
                else
                    i++;
            }
            return clienteEncontrado;
        }




        public bool modificarDireccion(string email, string direccion)

        {
            bool exito = false;
            Cliente c = BuscarCliente(email);
            if (c != null)
            {
                c.Direccion = direccion;
                exito = true;
            }

            return exito;
        }



        public bool BuscarEmail(string email)
        {
            bool encontre = false;
            int i = 0;
            while (!encontre && i < clientes.Count)
            {
                if (clientes[i].MailUnico == email)
                    encontre = true;
                else
                    i++;
            }
            return encontre;
        }
        public bool BuscarCedula(string cedula)
        {
            bool encontre = false;
            ClienteComun c;
            foreach (Cliente unCliente in clientes)
            {
                if (unCliente is ClienteComun)
                {
                    c = unCliente as ClienteComun;
                    if (c.Ci == cedula)
                        encontre = true;
                }
            }
            return encontre;
        }
        public bool BuscarRut(string rut)
        {
            bool encontre = false;
            ClienteEmpresa c;
            foreach (Cliente unC in clientes)
            {
                if (unC is ClienteEmpresa)
                {
                    c = unC as ClienteEmpresa;
                    if (c.Rut == rut)
                        encontre = true;
                }
            }
            return encontre;
        }

        public decimal DescuentoFormaDePagoYDpto(Factura F)
        {
            decimal precioTotal = F.CalcularTotalCompra();
            decimal precioTotalConDescuento = 0;

            if (precioTotal > 5000 && F.FormaDePago == "efectivo")
                precioTotal = precioTotal - (precioTotal * 4 / 100);
               
                   precioTotalConDescuento = precioTotal * F.Cliente.CalcularDescuento();

            if (F.Cliente.Mvd == "interior")
                precioTotalConDescuento += 1000;

            return precioTotalConDescuento;
        }

        public decimal TotalSDesc()
        {
            decimal totalSDesc = 0;
            foreach(Linea L in Aux)
            {
                totalSDesc += L.Total;
            }
            return totalSDesc;
        }

        public List<Linea> TopArticulo(Cliente unC)
        {
            List<Linea> top = new List<Linea>();
            string nombreUsuario = unC.Usuario.NombreUsuario;
            foreach (Factura f in facturas)
            {

                if (f.Cliente.Usuario.NombreUsuario == nombreUsuario)
                {
                    List<Linea> auxtop = f.Lineas;
                    top = LineasXfactura(auxtop);
                    //Factura unF = f;
                    //LineasXfactura(f);
                }
            }
            return top;
        }
        public List<Linea> LineasXfactura(List<Linea> auxtop)
        {
            decimal mayor = decimal.MinValue;
            List<Linea> top = new List<Linea>();
            foreach (Linea l in auxtop)
            {
                if ( l.Cantidad> mayor)
                {
                    mayor = l.Cantidad;
                    top.Clear();
                    top.Add(l);
                }
                else if (l.Cantidad == mayor)
                {
                    top.Add(l);
                }
            }
            return top ;
        }

        public List<Factura> ComprasPorCliente(string usuario)
        {
            List<Factura> aux = new List<Factura>();
            foreach (Factura f in facturas)
            {
                if (f.Cliente.Usuario.NombreUsuario == usuario)
                {
                    aux.Add(f);
                }
            }
            return aux;
        }

        public List<Factura> ComprasClientePorFecha(string usuario)
        {
            List<Factura> aux = new List<Factura>();
            List<Factura> facturas = ComprasPorCliente(usuario);
            facturas.Sort();
            foreach (Factura f in facturas)
            {
                aux.Add(f);
            }
            return aux;
        }


        public List<Linea> BuscarProductosLinea(string usuario)
        {
            List<Linea> lineasFiltradas = new List<Linea>();
            List<Factura> comCliente = ComprasClientePorFecha(usuario);
            foreach (Factura f in comCliente)
            {
                foreach (Linea li in f.Lineas)
                {
                    if (!lineasFiltradas.Contains(li))
                    {
                        lineasFiltradas.Add(li);
                    }
                }
            }
            return lineasFiltradas;
        }

        public List<Producto> UltimosDiezProductos(string usuario)
        {
            List<Linea> lineas = BuscarProductosLinea(usuario);
            List<Producto> productos = new List<Producto>();
            foreach (Linea li in lineas)
            {
                if (!productos.Contains(li.Producto) && productos.Count < 10)
                {
                    productos.Add(li.Producto);
                }
            }
            return productos;
        }

        public List<Factura> FacturaFiltrada(DateTime fechaDesde, DateTime fechaHasta)
        {
            List<Factura> aux = new List<Factura>();
            foreach(Factura f in facturas)
            {
                if (f.FechaCompra >= fechaDesde && f.FechaCompra <= fechaHasta)
                    aux.Add(f);
            }
            aux.Sort();
            return aux;
        }

        //public List<Linea> UltimosArticulos()
        //{
        //    List<Linea> articulos = new List<Linea>();
        //    int i = 0;
        //    foreach(Linea unL in Factura.lineas)
        //    {
        //        while (i <= 10)
        //      {
        //        i += unL.Cantidad;
        //        articulos.Add(unL);

        //       }


        //    }
        //    return articulos;

        //}
        #endregion
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dominio
{
    public  class ClienteComun: Cliente
    {
        #region Atributos
        private string ci;
        private string celular;
        private static  double descuentoCC;
        #endregion
        #region Propiedades GET/SET
       public string Ci
        {
            get { return ci; }
            set { ci = value; }
        }
        public string Celular
        {
            get { return celular;}
            set { celular = value; }
        }
        #endregion
        #region Constructor 
        // AGREGUE USUARIO, SAQUE STRING USUARIO UNICO

       public ClienteComun()
        {
            this.Usuario = new Usuario();
        }

        public ClienteComun(string nombre, string mailUnico, string direccion, string mvd, DateTime fechaIngreso,Usuario usuario,  string ci, string celular) : base(nombre, mailUnico, direccion, mvd, fechaIngreso, usuario)
        {
            this.ci = ci;
            this.celular = celular;
        }
        #endregion
        #region Override ToString
        public override string ToString()
        {
            string aux = "CLIENTE COMUN";
            aux += base.ToString();
            aux += "\nCedula: " + ci;
            aux += "\nCelular: " + celular;
            return aux;
        }
        #endregion
        #region Metodos
        ////////////////////////////Metodos para Validar datos////////////////////////////
        public static bool ValidarCedula(string ci)
        {
            return ci.Length == 8;
        }
        public static bool ValidarCelular(string celular)
        {
            return celular.Length == 9;
        }
        #endregion

        public override decimal CalcularDescuento()
        {
            decimal descuentoGeneral = 1;
            double antiguedad = (DateTime.Now - FechaIngreso).TotalDays;
            if (antiguedad > 730 && Mvd == "interior") {
                descuentoGeneral = descuentoGeneral - (descuentoGeneral*10/100);
            }
                   
            
            else if (antiguedad > 730)
                descuentoGeneral = descuentoGeneral - (descuentoGeneral*5/100);

            return descuentoGeneral;
        }

    }
}

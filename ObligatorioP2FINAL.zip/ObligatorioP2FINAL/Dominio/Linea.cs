﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dominio
{
    public class Linea
    {
        #region Atributos
        private Producto producto;
        private int cantidad;
        private decimal total;
        #endregion
        #region Propiedades GET/SET

        public Producto Producto
        {
            get { return producto; }
            set { producto = value; }
        }

        public int Cantidad
        {
            get { return cantidad; }
            set { cantidad = value; }
        }

        public decimal Total
        {
            get { return total; }
            set { total = value; }
        }

        #endregion
        #region Constructor

        public Linea(Producto producto, int cantidad, decimal total)
        {
            this.cantidad = cantidad;
            this.producto = producto;
            this.total = total;

        }
        #endregion
        #region Metodos
        public override string ToString()
        {
            string aux = "";
            aux += "\nProducto: " + producto;
            aux += "\nCantidad: " + cantidad + "\n";
            aux += "\nTotal: " + total + "\n";
            return aux;
        }
        #endregion
    }
}

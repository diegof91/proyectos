﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Dominio;

namespace ObligatorioClase.Controllers
{
    public class UsuarioController : Controller
    {
        // GET: Producto
        public ActionResult Index(string mensaje)
        {
            ViewBag.Mensaje = mensaje;
            return View();
        }
        public ActionResult Salir()
        {
            Session["rol"] = null;
            return Redirect("/Producto/Main");
        }
        [HttpGet]
        public ActionResult Validar(string nombre, string password)
        {
            Usuario unU = Sistema.Instancia.BuscarUsuario(nombre, password);
            Cliente unC = Sistema.Instancia.BuscarClientePorNombre(nombre);
            if(unC != null)
            {
                Session["cliente"] = unC.Usuario.NombreUsuario;
            }
            if (unU == null)
            {
                /*ViewBag.Mensaje = "Datos Erroneos";*/
                return RedirectToAction("Index", new { mensaje = "Datos Erroneos" });
            }

            Session["rol"] = unU.Rol;
            return Redirect("/Producto/Index");
        }
    }
}
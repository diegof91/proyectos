﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Dominio;

namespace ObligatorioClase.Controllers
{
    public class ProductoController : Controller
    {
        // GET: Producto
        public ActionResult Index(string mensaje)
        {
            if (Session["rol"] == null)
            {
                return Redirect("/Producto/Main");
            }
            if (Session["rol"].ToString() == "cliente")
                return Redirect("/Producto/IndexCarrito");

            ViewBag.mensaje = mensaje;
            ViewBag.productos = Sistema.Instancia.Productos;
            return View();
        }
        public ActionResult Main()
        {
            ViewBag.productos = Sistema.Instancia.Productos;
            return View();
        }

        public ActionResult borrarLista()
        {
            Sistema.Instancia.aux.Clear();
            return RedirectToAction("IndexCarrito");

        }
        public ActionResult IndexCarrito(string mensaje)
        {
            if (Session["rol"] == null)
            {
                return Redirect("/Producto/Main");
            }
            //Sistema.Instancia.aux.Clear();
            ViewBag.mensaje = mensaje;
            ViewBag.productos = Sistema.Instancia.Productos;
            return View();
        }

        [HttpGet]
        public ActionResult Alta()
        {
            if (Session["rol"] == null)
            {
                return Redirect("/Producto/Main");
            }
            return View(new Producto());

        }

        [HttpPost]
        public ActionResult Alta(Producto unP)
        {
            if (Producto.ValidarCategoria(unP.Categoria) && Producto.ValidarEntradaDatos(unP.Nombre, unP.Descripcion, unP.Exclusividad, unP.Categoria, unP.PrecioUnit) && Producto.ValidarExclusividad(unP.Exclusividad))
            {
                if (Sistema.Instancia.AgregarProducto(unP.Nombre, unP.Descripcion, unP.Exclusividad, unP.Categoria, unP.PrecioUnit))
                {
                    return RedirectToAction("Index", new { mensaje = "Alta Producto Exitosa" });
                }
                else
                {
                    ViewBag.Mensaje = "El producto ya existe";
                    return View(unP);
                }
            }
            else
            {
                ViewBag.Mensaje = "Datos erroneos. Ingresar datos nuevamente";
                return View(unP);
            }
        }


        [HttpGet]
        public ActionResult ModificacionProducto(int id)
        {
            if (Session["rol"] == null || id == 0)
            {
                return Redirect("/Producto/Main");
            }
            Producto p = Sistema.Instancia.BuscarProducto(id);
            ViewBag.Id = id;
            return View("ModificacionProducto", p);
        }

        [HttpPost]
        public ActionResult ModificacionProducto(int id, decimal precioUnit)
        {
            if (Sistema.Instancia.modificarPrecioProducto(id, precioUnit))
            {
                return RedirectToAction("Index", new { mensaje = "modificacion Exitosa" });
            }
            else
            {
                ViewBag.Mensaje = "Datos erroneos. Ingresar datos nuevamente";
                return View("ModifcacionProducto");
            }

        }

        [HttpPost]
        public ActionResult AgregarCarrito(int id, int cantidad)
        {
            Linea unL = Sistema.Instancia.AgregarProductoALinea(id, cantidad);
            if (unL !=null)
            {
                return RedirectToAction("IndexCarrito", new { mensaje = "Producto agregado!" });
            }
            else
            {
                ViewBag.mensaje = "El producto no ha sido agregado";
                return View("IndexCarrito");
            }
        }
    }
}

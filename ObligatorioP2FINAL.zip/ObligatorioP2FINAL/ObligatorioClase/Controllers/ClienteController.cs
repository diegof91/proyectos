﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Dominio;

namespace ObligatorioClase.Controllers
{
    public class ClienteController : Controller
    {
        // GET: Cliente
        public ActionResult Index(string mensaje)
        {
            if (Session["rol"] == null)
            {
                return Redirect("/Producto/Main");
            }
            ViewBag.Mensaje = mensaje;
            ViewBag.cliente = Sistema.Instancia.Clientes;
            
            return View();
        }

        [HttpGet]
        public ActionResult AltaClienteComun()
        {
            if (Session["rol"] == null)
            {
                return Redirect("/Producto/Main");
            }
            return View(new ClienteComun());

        }

        [HttpPost]
        public ActionResult AltaClienteComun(ClienteComun unComun)
        {
            if (ClienteComun.ValidarCedula(unComun.Ci) && ClienteComun.ValidarCelular(unComun.Celular) && ClienteComun.ValidarMVD(unComun.Mvd))
            {
                if (Sistema.Instancia.AgregarClienteComun(unComun.Nombre,unComun.MailUnico,unComun.Direccion,unComun.Mvd,unComun.FechaIngreso,unComun.Usuario,unComun.Ci,unComun.Celular))
                {
                    
                    return RedirectToAction("Index", new { mensaje = "Alta Cliente Comun Exitosa" });
                }
                else
                {
                    ViewBag.Mensaje = "El cliente comun ya existe";
                    return View(unComun);
                }
            }
            else
            {
                ViewBag.Mensaje = "Datos erroneos. Ingresar datos nuevamente";
                return View(unComun);
            }
        }

        [HttpGet]
        public ActionResult ModificacionCliente(string mailUnico)
        {
            if (Session["rol"] == null)
            {
                return Redirect("/Producto/Main");
            }
            Cliente c = Sistema.Instancia.BuscarCliente(mailUnico);
            ViewBag.mailUnico = mailUnico;
            return View("ModificacionCliente", c);

        }

        [HttpPost]
        public ActionResult ModificacionCliente(string mailUnico, string direccion)

        {
            if (Sistema.Instancia.modificarDireccion(mailUnico, direccion))
            {
                return RedirectToAction("Index", new { mensaje = "modificacion Exitosa" });
            }
            else
            {
                ViewBag.mensaje = "Datos erroneos. Ingresar datos nuevamente";
                return View("ModifcacionCliente");
            }

        }
    }
}
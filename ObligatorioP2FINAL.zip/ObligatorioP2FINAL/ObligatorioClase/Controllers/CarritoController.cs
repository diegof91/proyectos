﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Dominio;

namespace ObligatorioClase.Controllers
{
    public class CarritoController : Controller
    {
        // GET: Carrito
        public ActionResult Index(string mensaje)
        {
            if (Session["rol"] == null)
            {
                return Redirect("/Producto/Main");
            }
            if (Session["rol"].ToString() != "cliente")
                return Redirect("/Producto/IndexCarrito");
            ViewBag.mensaje = mensaje;
            ViewBag.Aux = Sistema.Instancia.Aux;
            ViewBag.TotalSDesc = Sistema.Instancia.TotalSDesc();
            return View();
        }


        public ActionResult Top()
        {
            if (Session["rol"] == null)
            {
                return Redirect("/Producto/Main");
            }
            
            string nombreUsusario = Session["cliente"].ToString();
            Cliente unC = Sistema.Instancia.BuscarClientePorNombre(nombreUsusario);
            ViewBag.TopArticulo = Sistema.Instancia.TopArticulo(unC);
            return View();
        }

        public ActionResult Ultimos()
        {
            if (Session["rol"] == null)
                return Redirect("/Producto/Main");

            if (Session["rol"].ToString() != "cliente")
                return RedirectToAction("/Producto/Index");

            string nombreUsuario = Session["cliente"].ToString();
            List<Producto> productos = Sistema.Instancia.UltimosDiezProductos(nombreUsuario);
            ViewBag.UltimosProductos = productos;

            return View();
        }
    }
}
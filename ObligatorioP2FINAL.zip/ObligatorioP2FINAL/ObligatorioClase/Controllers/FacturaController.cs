﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Dominio;

namespace ObligatorioClase.Controllers
{
    public class FacturaController : Controller
    {
        // GET: Factura
        public ActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public ActionResult Alta(Factura F)
        {
            if (Session["rol"] == null)
            {
                return Redirect("/Producto/Main");
            }
            return View("FacturaCliente", F);
        }

        [HttpPost]
        public ActionResult Alta(string formaDePago, string formaDeEntrega)
        {
            string nombre = Session["cliente"].ToString() ;
            Cliente unC = Sistema.Instancia.BuscarClientePorNombre(nombre);           
            List<Linea> aux = Sistema.Instancia.Aux;
            DateTime fechaCompra = DateTime.Now;

            Factura F = Sistema.Instancia.AgregarFactura(formaDePago, formaDeEntrega, fechaCompra, aux, unC);
            Session["factura"] = F;
            return RedirectToAction("Alta",F); 
        }


        public ActionResult FacturaCliente()
        {
            if (Session["rol"] == null)
            {
                return Redirect("/Producto/Main");
            }
            return View();
        }

        public ActionResult ListarFacturas()
        {
            if (Session["rol"] == null)
            {
                return Redirect("/Producto/Main");
            }
            if (Session["rol"].ToString() == "cliente")
                return Redirect("/Producto/IndexCarrito");
            ViewBag.Facturas = Sistema.Instancia.Facturas;
            ViewBag.FechaDesde = DateTime.Now;
            ViewBag.FechaHasta = DateTime.Now;
            return View("FiltrarFechas");
        }

        [HttpPost]
        public ActionResult FiltrarFechas(DateTime fechaDesde, DateTime fechaHasta)
        {
            if (Session["rol"] == null)
            {
                return Redirect("/Producto/Main");
            }
            if (Session["rol"].ToString() == "cliente")
                return Redirect("/Producto/IndexCarrito");
            ViewBag.Facturas = Sistema.Instancia.FacturaFiltrada(fechaDesde, fechaHasta);
            ViewBag.FechaDesde = fechaDesde;
            ViewBag.FechaHasta = fechaHasta;
            return View("FiltrarFechas");
        }


    }

    
}